from django.urls import path

from Payment.views import EsewaVerifyView

urlpatterns = [
    path("esewa-verify/", EsewaVerifyView.as_view(), name="esewaverify"),

]
