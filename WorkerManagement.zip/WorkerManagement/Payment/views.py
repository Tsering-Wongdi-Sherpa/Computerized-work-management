from datetime import date

from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.views.generic import View
import requests
# for the esewa payment gateway
from notifications.signals import notify

from Workmanagement.models import WorkOrder

class EsewaVerifyView(View):
    def get(self, request, *args, **kwargs):
        import xml.etree.ElementTree as ET
        oid = request.GET.get("oid")
        amt = request.GET.get("amt")
        refId = request.GET.get("refId")

        url = "https://uat.esewa.com.np/epay/transrec"
        d = {
            'amt': amt,
            'scd': 'epay_payment',
            'rid': refId,
            'pid': oid,
        }
        resp = requests.post(url, d)
        root = ET.fromstring(resp.content)
        status = root[0].text.strip()
        work_id = oid.split("_")[1]
        order_obj = WorkOrder.objects.get(id=work_id)
        if status == "Success":
            order_obj.payment_completed = True
            order_obj.settlement_date = date.today()
            order_obj.save()
            # for sending system notifications this notification sends only after payment is done successfully
            sender = User.objects.get(username=order_obj.order.user.username)
            receiver = User.objects.get(username=order_obj.worker.user.username)
            notify.send(sender, recipient=receiver, verb='Message', description=f"{order_obj.order.user.first_name}"
                                                                                f"{order_obj.order.user.last_name} Made your payment "
                                                                                f"{amt} for {order_obj.work_description}")
            return redirect("/")
        else:
            return redirect("/esewa-request/?o_id=" + work_id)
