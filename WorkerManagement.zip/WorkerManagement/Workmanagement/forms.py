from django import forms

from Workmanagement.models import WorkOrder

class OrderCreationForm(forms.ModelForm):
    class Meta:
        model = WorkOrder
        fields = {'worker',
                  'order',
                  'latitude',
                  'longitude',
                  'work_description',
                  'scheduled_date',
                  'status',
                  'priority',
                  'work_photo'}



