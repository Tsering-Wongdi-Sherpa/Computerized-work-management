from django.conf import settings
from django.contrib.auth.models import User
from django.contrib import messages
from django.shortcuts import render, redirect
from django.views import View
from notifications.signals import notify
from twilio.rest import Client

from Usermanagement.models import UserProfile, CustomerProfile
from Workmanagement.forms import OrderCreationForm
from Workmanagement.models import WorkOrder
from Workmanagement.views.location import CurrentLocation


class WorkOrderCreateView(View):
    def get(self, request):
        ordercreationform = OrderCreationForm()
        context = {
            'ordercreationform': ordercreationform}
        return render(request, 'Workmanagement/workorder_createview.html', context)

    def post(self, request):
        workerId = request.POST.get('worker')
        worker = UserProfile.objects.get(id=workerId)
        lat = CurrentLocation.latitude
        lon = CurrentLocation.longitude
        ordercreationform = OrderCreationForm(request.POST)
        if ordercreationform.is_valid():
            orderform = ordercreationform.save(commit=False)
            orderform.save()
            # for sending system notifications this notification sends only after payment is done successfully
            sender = User.objects.get(username=self.request.user)
            receiver = User.objects.get(username=worker.user.username)
            notify.send(sender, recipient=receiver, verb='Message', description=f"{self.request.user.first_name}"
                                                                                f"{self.request.user.last_name} posted new order")

            # for twilio SMS notification
            # account_sid = getattr(settings, 'TWILIO_ACCOUNT_SID')
            # auth_token = getattr(settings, 'TWILIO_AUTH_TOKEN')
            # client = Client(account_sid, auth_token)
            #
            # message = client.messages \
            #     .create(
            #     body=f"{self.request.user.first_name}"
            #          f"{self.request.user.last_name} posted new order",
            #     from_=getattr(settings, 'TWILIO_NUMBER'),
            #     to=f'+977{worker.phone}'
            # )
            # print(message.sid)
            messages.success(request, ('Your request is created successfully'), fail_silently=True)
            return redirect('index')

        context = {'ordercreationform': ordercreationform, 'worker': worker,
                   'lat': lat, 'lon': lon}
        return render(request, 'Workmanagement/workorder_createview.html', context)
