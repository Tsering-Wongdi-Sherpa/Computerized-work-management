from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
# specific to this view
from django.views.generic import ListView
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from Usermanagement.models import CustomerProfile, UserProfile
from Workmanagement.models import WorkOrder

#@method_decorator(permission_required('is_superuser'), name='dispatch')
@method_decorator(login_required, name='dispatch')
class BillListView(ListView):

    model = WorkOrder
    template_name = 'Workmanagement/billing_listview.html'
    context_object_name = 'billing'
    paginate_by = 15

    def get_context_data(self, **kwargs):
        context = super(BillListView, self).get_context_data(**kwargs)
        if not self.request.user.is_staff:
            customer = CustomerProfile.objects.get(user__id=self.request.user.id)
            billing = self.get_queryset().filter(order=customer, status= "Completed",  payment_completed = "True")
        elif self.request.user.is_staff and not self.request.user.is_superuser:
            worker = UserProfile.objects.get(user__id=self.request.user.id)
            billing = self.get_queryset().filter(worker=worker, status="Completed", payment_completed="True")
        else:
            billing = self.get_queryset().filter(status="Completed", payment_completed="True")

        page = self.request.GET.get('page')
        paginator = Paginator(billing, self.paginate_by)
        try:
            billing = paginator.page(page)
        except PageNotAnInteger:
            billing = paginator.page(1)
        except EmptyPage:
            billing = paginator.page(paginator.num_pages)
        context['billing'] = billing
        return context