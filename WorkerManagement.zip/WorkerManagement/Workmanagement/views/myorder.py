from django.contrib.auth.decorators import login_required
from django.db.models import Sum,Value
from django.db.models.functions import Coalesce
from django.utils.decorators import method_decorator
# specific to this view
from django.views.generic import ListView
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from Usermanagement.models import CustomerProfile, UserProfile
from Workmanagement.models import WorkOrder

#@method_decorator(permission_required('is_superuser'), name='dispatch')
@method_decorator(login_required, name='dispatch')
class MyOrderListView(ListView):

    model = WorkOrder
    template_name = 'Workmanagement/myorder_listview.html'
    context_object_name = 'myorder'
    paginate_by = 15

    def get_context_data(self, **kwargs):
        context = super(MyOrderListView, self).get_context_data(**kwargs)
        customer = CustomerProfile.objects.get(user__id=self.request.user.id)
        myorder = self.get_queryset().filter(order=customer, status= "Completed",  payment_completed = "False")

        page = self.request.GET.get('page')
        paginator = Paginator(myorder, self.paginate_by)
        try:
            myorder = paginator.page(page)
        except PageNotAnInteger:
            myorder = paginator.page(1)
        except EmptyPage:
            myorder = paginator.page(paginator.num_pages)
        context['myorder'] = myorder
        return context