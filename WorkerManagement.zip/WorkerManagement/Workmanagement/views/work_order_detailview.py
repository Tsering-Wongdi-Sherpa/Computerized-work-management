from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
# specific to this view
from django.views.generic.detail import DetailView
from Workmanagement.models import WorkOrder

@method_decorator(login_required, name='dispatch')
class WorkOrderDetailView(DetailView):
    model = WorkOrder
    template_name = 'Workmanagement/workorder_detailview.html'
    context_object_name = 'workorder'
