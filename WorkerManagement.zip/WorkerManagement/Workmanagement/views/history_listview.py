from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views.generic import ListView
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from field_history.models import FieldHistory

@method_decorator(login_required, name='dispatch')
class HistoryListView(ListView):

    model = FieldHistory
    template_name = 'Workmanagement/history_listview.html'
    context_object_name = 'histories'
    paginate_by = 12

    def get_context_data(self, **kwargs):
        context = super(HistoryListView, self).get_context_data(**kwargs)
        histories = self.get_queryset()
        page = self.request.GET.get('page')
        paginator = Paginator(histories, self.paginate_by)
        try:
            histories = paginator.page(page)
        except PageNotAnInteger:
            histories = paginator.page(1)
        except EmptyPage:
            histories = paginator.page(paginator.num_pages)
        context['histories'] = histories
        return context