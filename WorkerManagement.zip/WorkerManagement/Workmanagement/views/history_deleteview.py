from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required, permission_required
# specific to this view
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from field_history.models import FieldHistory

from Workmanagement.models import WorkOrder

@method_decorator(login_required, name='dispatch')
class HistoryDeleteView(DeleteView):
    model = FieldHistory
    template_name = 'Usermanagement/delete.html'
    success_url = reverse_lazy('history-list')