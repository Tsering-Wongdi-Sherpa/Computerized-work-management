from ipstack import GeoLookup


class CurrentLocation:
    # Create the GeoLookup object using your API key.
    geo_lookup = GeoLookup("17be87cafa128d22053291519cfc65e9")
    location = geo_lookup.get_own_location()
    latitude = location['latitude']
    longitude = location['longitude']
    region = location['region_name']
    city = location['city']
    coordinate = latitude, longitude
