from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth.models import User
from django.utils.decorators import method_decorator
# specific to this view
from django.views.generic import ListView
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from Workmanagement.models import WorkOrder

#@method_decorator(permission_required('is_superuser'), name='dispatch')
@method_decorator(login_required, name='dispatch')
class WorkOrderListView(ListView):

    model = WorkOrder
    template_name = 'Workmanagement/workorder_pending_listview.html'
    context_object_name = 'workorder'
    paginate_by = 10

    def get_context_data(self, **kwargs):
        context = super(WorkOrderListView, self).get_context_data(**kwargs)
        workorder = self.get_queryset().filter(status="In Progress")
        page = self.request.GET.get('page')
        paginator = Paginator(workorder, self.paginate_by)
        try:
            workorder = paginator.page(page)
        except PageNotAnInteger:
            workorder = paginator.page(1)
        except EmptyPage:
            workorder = paginator.page(paginator.num_pages)
        context['workorder'] = workorder
        return context