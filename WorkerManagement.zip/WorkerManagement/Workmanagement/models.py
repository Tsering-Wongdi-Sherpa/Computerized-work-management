# import the standard Django Model
# from built-in library
from django.contrib.auth.models import User
from django.db import models
from django.urls import reverse
from field_history.tracker import FieldHistoryTracker
from notifications.signals import notify

from Usermanagement.models import CustomerProfile, UserProfile
# importing for twilo sms
from twilio.rest import Client
from django.conf import settings


class WorkOrder(models.Model):
    PRIORITY = (
        ('Medium', 'Medium'),
        ('High', 'High'),
        ('Low', 'Low'),
    )
    STATUS = (
        ('Pending', 'Pending'),
        ('In Progress', 'In Progess'),
        ('Completed', 'Completed'),
    )
    PAYMENT = (
        ('Pay later', 'Pay later'),
        ('Esewa', 'Esewa'),
    )
    worker = models.ForeignKey(UserProfile, on_delete=models.SET_NULL, null=True)
    order = models.ForeignKey(CustomerProfile, on_delete=models.SET_NULL, null=True)
    date_requested = models.DateTimeField(auto_now_add=True)
    work_description = models.TextField(blank=False)
    scheduled_date = models.DateField(blank=False)
    latitude = models.CharField(max_length=30)
    longitude = models.CharField(max_length=30)
    priority = models.CharField(max_length=20, choices=PRIORITY, default=PRIORITY)
    payment_completed = models.BooleanField(default=False, null=True, blank=True)
    settelment_date = models.DateField(null=True)
    status = models.CharField(max_length=20, choices=STATUS, default=STATUS)
    work_photo = models.ImageField(upload_to='work_picture', blank=True)
    # for the history
    field_history = FieldHistoryTracker(['work_description'])

    def __str__(self):
        return str(self.worker)

    @property
    def _field_history_user(self):
        return self.order.user

    @property
    def get_html_url(self):
        url = reverse('Workmanagement:workorder-detail', args=(self.id,))
        return f'<a href="{url}"> {self.work_description} </a>'
