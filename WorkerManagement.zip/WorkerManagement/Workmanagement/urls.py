from django.urls import path
from django.contrib.auth import views as auth_views

from Workmanagement.views import work_order_createview, work_order_listview, work_order_deleteview, \
    work_order_detailview, work_order_updateview, work_order_listview_pending, \
    work_order_listview_completed, work_order_listview_progress, history_listview, myorder, history_deleteview, billing

urlpatterns = [
    path('order/create', work_order_createview.WorkOrderCreateView.as_view(), name='workorder-create'),
    path('order', work_order_listview.WorkOrderListView.as_view(), name='workorder-list'),
    path('order_pending', work_order_listview_pending.WorkOrderListView.as_view(), name='workorder-pending'),
    path('order_complete', work_order_listview_completed.WorkOrderListView.as_view(), name='workorder-complete'),
    path('order_progress', work_order_listview_progress.WorkOrderListView.as_view(), name='workorder-progress'),
    path('order/<int:pk>/delete', work_order_deleteview.WorkOrderDeleteView.as_view(), name='workorder-delete'),
    path('history/<int:pk>/delete', history_deleteview.HistoryDeleteView.as_view(), name='history-delete'),
    path('order/<int:pk>', work_order_detailview.WorkOrderDetailView.as_view(), name='workorder-detail'),
    path('order/<int:pk>/update', work_order_updateview.WorkOrderUpdateView.as_view(), name='workorder-update'),
    path('history/', history_listview.HistoryListView.as_view(), name="history-list"),
    path('billing/', billing.BillListView.as_view(), name="billing"),
    path('myorder/', myorder.MyOrderListView.as_view(), name="myorder-list"),
]
