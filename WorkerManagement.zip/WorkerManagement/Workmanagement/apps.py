from django.apps import AppConfig


class WorkmanagementConfig(AppConfig):
    name = 'Workmanagement'
