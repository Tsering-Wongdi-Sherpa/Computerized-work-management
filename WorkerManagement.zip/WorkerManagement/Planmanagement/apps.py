from django.apps import AppConfig


class PlanmanagementConfig(AppConfig):
    name = 'Planmanagement'
