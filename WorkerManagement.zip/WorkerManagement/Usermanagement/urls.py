from django.urls import path
from django.contrib.auth import views as auth_views
from Usermanagement.views import index, login_logout, worker_signup, customer_signup, change_password, worker_profile, \
    view_profile, customer_listview, customer_createview, customer_deleteview, customer_detailview, \
    customer_updateview, worker_listview, worker_detailview, worker_deleteview, worker_updateview, admin_dashboard, \
     customer_profile, worker_createview

urlpatterns = [
    path('', index.Home.as_view(), name='index'),
    path('signup/', worker_signup.WorkerSignup.as_view(), name='signup'),
    path('login/', login_logout.Login.as_view(), name='login'),
    path('register/', customer_signup.CustomerSignup.as_view(), name='register'),
    path('logout/', login_logout.Logout.as_view(), name='logout'),
    path('profile/', view_profile.ViewProfile.as_view(), name='profile'),
    path('update_worker_profile/', worker_profile.WorkerProfileUpdateView.as_view(), name='worker-profile-update'),
    # URL below are only for admin
    path('dashboard/', admin_dashboard.Dashboard.as_view(), name='admin_dashboard'),
    # for customer profile
    path('customer', customer_listview.CustomerListView.as_view(), name='customer-list'),
    path('customer/create', customer_createview.CustomerCreateView.as_view(), name='customer-create'),
    path('customer/<int:pk>/delete', customer_deleteview.CustomerDeleteView.as_view(), name='customer-delete'),
    path('customer/<int:pk>', customer_detailview.CustomerDetailView.as_view(), name='customer-detail'),
    path('customer/<int:pk>/update', customer_updateview.CustomerUpdateView.as_view(), name='customer-update'),
    # path('cusotmer_profile/', customer_profile)
    path('customer_profile/update', customer_profile.CustomerProfileUpdateView.as_view(), name='customer-profile-update'),

    # for worker profile
    path('worker_create/', worker_createview.WorkerCreateView.as_view(), name='worker-create'),
    path('worker', worker_listview.WorkerListView.as_view(), name='worker-list'),
    path('worker/<int:pk>', worker_detailview.WorkerDetailView.as_view(), name='worker-detail'),
    path('worker/<int:pk>/delete', worker_deleteview.WorkerDeleteView.as_view(), name='worker-delete'),
    path('worker/<int:pk>/update', worker_updateview.WorkerUpdateView.as_view(), name='worker-update'),
    # for changing password after login
    path('password-change/', change_password.ChangePassword.as_view(), name='change_password'),
    # for resetting password
    path('reset_password/', auth_views.PasswordResetView.as_view(template_name="Usermanagement/password_reset.html"),
         name="reset_password"),
    path('reset_password_sent/',
         auth_views.PasswordResetDoneView.as_view(template_name="Usermanagement/password_reset_sent.html"),
         name="password_reset_done"),
    path('reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(template_name="Usermanagement/password_reset_form.html"),
         name="password_reset_confirm"),
    path('reset_password_complete/',
         auth_views.PasswordResetCompleteView.as_view(template_name="Usermanagement/password_reset_done.html"),
         name="password_reset_complete"),
]
