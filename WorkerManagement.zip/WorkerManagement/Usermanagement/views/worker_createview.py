from django.contrib import messages
from django.shortcuts import render, redirect
from django.views.generic import CreateView
from ipstack import GeoLookup
from Usermanagement.forms import WorkerCreationForm, DetailForm


class WorkerCreateView(CreateView):
    def get(self, request):
        # Create the GeoLookup object using your API key.
        geo_lookup = GeoLookup("17be87cafa128d22053291519cfc65e9")
        location = geo_lookup.get_own_location()
        lat = location['latitude']
        lon = location['longitude']
        region = location['city']
        city = lat, lon
        form = WorkerCreationForm()
        detail_form = DetailForm()
        context = {'form': form, 'detail_form': detail_form, 'city': city}
        return render(request, 'Usermanagement/worker_createview.html', context)
    def post(self, request):
        form = WorkerCreationForm(request.POST)
        detail_form = DetailForm(request.POST)
        if form.is_valid() and detail_form.is_valid():
            user = form.save()
            form = detail_form.save(commit=False)
            form.user = user
            form.save()
            return redirect('worker-list')
        context = {'form':form, 'detail_form':detail_form}
        return render(request, 'Usermanagement/worker_createview.html', context)