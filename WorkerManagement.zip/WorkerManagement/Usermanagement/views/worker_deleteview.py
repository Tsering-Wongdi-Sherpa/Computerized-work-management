from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required, permission_required
# specific to this view
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy

from Usermanagement.models import UserProfile

@method_decorator(permission_required('is_superuser'), name='dispatch')
@method_decorator(login_required, name='dispatch')
class WorkerDeleteView(DeleteView):
    model = UserProfile
    template_name = 'Usermanagement/delete.html'
    success_url = reverse_lazy('worker-list')