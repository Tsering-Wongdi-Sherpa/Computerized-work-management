from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
# specific to this view
from django.views.generic.detail import DetailView
from Usermanagement.models import UserProfile

@method_decorator(login_required, name='dispatch')
class WorkerDetailView(DetailView):
    model = UserProfile
    template_name = 'Usermanagement/worker_detailveiw.html'
    context_object_name = 'worker'