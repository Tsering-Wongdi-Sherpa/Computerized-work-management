from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.utils.decorators import method_decorator
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib import messages
from django.views import View

@method_decorator(login_required, name='dispatch')
class ChangePassword(View):
    def get(self, request):
        form = PasswordChangeForm(request.user)
        return render(request, 'Usermanagement/password_change_form.html', {
            'form': form
        })
    def post(self, request):
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)
            messages.success(request, ('Your password is updated successfully'))
            return redirect('index')
        else:
            messages.error(request, ('Password does not matched !!!'))

        return render(request, 'Usermanagement/password_change_form.html', {
            'form': form
        })
