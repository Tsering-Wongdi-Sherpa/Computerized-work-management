from datetime import date
from django.views.generic import TemplateView

from Usermanagement.models import CustomerProfile, UserProfile
from Workmanagement.models import WorkOrder


class Dashboard(TemplateView):
    template_name = 'Usermanagement/admin_dashboard.html'
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["orders"] = WorkOrder.objects.all()
        today = date.today()
        context["today_request"] = WorkOrder.objects.filter(date_requested__year=today.year,
                                                            date_requested__month=today.month,
                                                            date_requested__day = today.day
                                                            )
        context["today_request_personal"] = WorkOrder.objects.filter(date_requested__year=today.year,
                                                            date_requested__month=today.month,
                                                            date_requested__day=today.day,
                                                            worker__user__username = self.request.user.username,
                                                            )
        # for status in admin dashboard
        context["pending"] = WorkOrder.objects.filter(status="Pending").count()
        context["progress"] = WorkOrder.objects.filter(status="In Progress").count()
        context["completed"] = WorkOrder.objects.filter(status="Completed").count()
        # for workorder in one week
        context["high"] = WorkOrder.objects.filter(priority="High").count()
        context["medium"] = WorkOrder.objects.filter(priority="Medium").count()
        context["low"] = WorkOrder.objects.filter(priority="Low").count()
        # for customer and worker ratio
        context["customer"] = CustomerProfile.objects.all().count()
        context["worker"] = UserProfile.objects.all().count()
        return context
