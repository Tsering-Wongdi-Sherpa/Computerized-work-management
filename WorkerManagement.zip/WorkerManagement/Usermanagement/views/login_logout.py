from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import render, redirect
from django.views import View
from django.views.generic import TemplateView
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# For the login
class Login(View):
    def get(self, request):
        context = {}
        return render(request, 'Usermanagement/login.html', context)

    def post(self, request):
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None and user.is_superuser:
            login(request, user)
            return redirect('admin_dashboard')
        elif user is not None and user.is_staff:
            login(request, user)
            return redirect('worker_dashboard')
        elif user is not None and not user.is_staff and not user.is_superuser:
            login(request, user)
            messages.success(request, ('Your are welcome'))
            return redirect('index')
        else:
            messages.info(request, 'Username and Password does not matched')

        context = {}
        return render(request, 'Usermanagement/login.html', context)

#for user logout
class Logout(View):
    def get(self, request):
        logout(request)
        return redirect('index')

#for social account login
class HomeView(LoginRequiredMixin, TemplateView):
    template_name = "Usermanagement/index.html"