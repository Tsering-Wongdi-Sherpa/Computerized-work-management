from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
# specific to this view
from django.views.generic.detail import DetailView
from Usermanagement.models import CustomerProfile

@method_decorator(login_required, name='dispatch')
class CustomerDetailView(DetailView):
    model = CustomerProfile
    template_name = 'Usermanagement/customer_detailview.html'
    context_object_name = 'customer'
