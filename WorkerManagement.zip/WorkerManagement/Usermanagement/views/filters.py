import django_filters
from Usermanagement.models import UserProfile

class WorkerFilter(django_filters.FilterSet):

    class Meta:
        model = UserProfile
        fields = {
            'user__first_name': ['icontains'],
            'location': ['icontains'],
            'pan': ['icontains'],
            'phone': ['icontains'],
            'catagory': ['icontains'],
        }