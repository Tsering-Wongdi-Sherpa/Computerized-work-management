from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
# specific to this view
from django.views.generic.edit import UpdateView
from Usermanagement.models import UserProfile

@method_decorator(login_required, name='dispatch')
class WorkerUpdateView(UpdateView):
    model = UserProfile
    fields = ['phone', 'photo', 'bio']
    template_name = 'Usermanagement/worker_updateview.html'
    context_object_name = 'worker'
    success_url = reverse_lazy('worker-list')

