from django.contrib import messages
from django.shortcuts import render, redirect
from Usermanagement.forms import CustomerForm, CustomerCreationForm
from django.views import View

# this is for the customer creation form
class CustomerCreateView(View):
    def get(self, request):
        customer = CustomerCreationForm()
        customer_form = CustomerForm()
        context = {'customer': customer, 'customer_form': customer_form}
        return render(request, 'Usermanagement/customer_createview.html', context)
    def post(self, request):
        customer = CustomerCreationForm(request.POST)
        customer_form = CustomerForm(request.POST)

        if customer.is_valid() and customer_form.is_valid():
            user = customer.save()
            customer = customer_form.save(commit=False)
            customer.user = user
            customer.save()
            messages.success(request, ('Your account is created successfully'))
            return redirect('customer-list')

        context = {'customer': customer, 'customer_form': customer_form}
        return render(request, 'Usermanagement/customer_createview.html', context)