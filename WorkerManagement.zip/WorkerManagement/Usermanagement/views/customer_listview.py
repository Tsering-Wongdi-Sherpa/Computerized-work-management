# store/views.py
from django.contrib.auth.decorators import login_required, permission_required
from django.utils.decorators import method_decorator
# specific to this view
from django.views.generic import ListView
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage

from Usermanagement.models import CustomerProfile


@method_decorator(permission_required('is_superuser'), name='dispatch')
@method_decorator(login_required, name='dispatch')
class CustomerListView(ListView):

    model = CustomerProfile
    template_name = 'Usermanagement/customer_list.html'
    context_object_name = 'customers'
    paginate_by = 15

    def get_context_data(self, **kwargs):
        context = super(CustomerListView, self).get_context_data(**kwargs)
        customers = self.get_queryset()
        page = self.request.GET.get('page')
        paginator = Paginator(customers, self.paginate_by)
        try:
            customers = paginator.page(page)
        except PageNotAnInteger:
            customers = paginator.page(1)
        except EmptyPage:
            customers = paginator.page(paginator.num_pages)
        context= {'customers': customers}
        return context