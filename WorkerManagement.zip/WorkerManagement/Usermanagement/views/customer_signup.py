from django.contrib import messages
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from notifications.signals import notify

from Usermanagement.forms import CustomerForm, CustomerCreationForm
from django.views import View

# this is for the customer creation form
class CustomerSignup(View):
    def get(self, request):
        customer = CustomerCreationForm()
        customer_form = CustomerForm()
        context = {'customer': customer, 'customer_form': customer_form}
        return render(request, 'Usermanagement/userregister.html', context)
    def post(self, request):
        customer = CustomerCreationForm(request.POST)
        customer_form = CustomerForm(request.POST)

        if customer.is_valid() and customer_form.is_valid():
            user = customer.save()
            customer = customer_form.save(commit=False)
            customer.user = user
            customer.save()
            # for sending system notifications this notification sends only after payment is done successfully
            sender = User.objects.get(username=user.username)
            receiver = User.objects.filter(is_superuser="True")
            notify.send(sender, recipient=receiver, verb='Message', description=f"{sender.first_name}"
                                                                                f"{sender.last_name} Registered as customer")
            messages.success(request, ('Your account is created successfully'))
            return redirect('login')

        context = {'customer': customer, 'customer_form': customer_form}
        return render(request, 'Usermanagement/userregister.html', context)
