from django.urls import reverse_lazy
from django.utils.decorators import method_decorator
from django.contrib.auth.decorators import login_required
# specific to this view
from django.views.generic.edit import UpdateView
from Usermanagement.models import CustomerProfile

@method_decorator(login_required, name='dispatch')
class CustomerUpdateView(UpdateView):
    model = CustomerProfile
    fields = ['phone', 'photo']
    template_name = 'Usermanagement/customer_updateview.html'
    context_object_name = 'customer'
    success_url = reverse_lazy('customer-list')

