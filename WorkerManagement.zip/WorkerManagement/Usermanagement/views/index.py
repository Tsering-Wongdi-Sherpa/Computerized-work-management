from django.shortcuts import render
from django.views import View

from Usermanagement.models import UserProfile, CustomerProfile
from Workmanagement.views.location import CurrentLocation

class Home(View):
    def get(self, request):
        # Create the GeoLookup object using your API key.
        city = CurrentLocation.city
        coordinate = CurrentLocation.latitude, CurrentLocation.longitude
        workers = UserProfile.objects.all()
        #workers = UserProfile.objects.filter(location=region)
        print(request.user.id)
        context = {'workers': workers, 'city': city, 'coordinate': coordinate}
        return render(request, 'Usermanagement/index.html', context)
