from django.core.validators import RegexValidator
from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.urls import reverse
from field_history.tracker import FieldHistoryTracker
from multiselectfield import MultiSelectField


class UserProfile(models.Model):
    CATEGORY = (
        ('Electrician', 'Electrician'),
        ('Plumber', 'Plumber'),
        ('Carpenter', 'Carpenter'),
        ('Cleaner', 'Cleaner'),
        ('Beautician', 'Beautician'),
        ('Interior Designer', 'Interior Designer'),
        ('Constructor', 'Constructor'),
    )
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    catagory = MultiSelectField(choices=CATEGORY)
    location = models.CharField(max_length=300, blank=False)
    pan = models.CharField(max_length=20, blank=False, unique=True)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,12}$',
                                 message="Phone number must be entered in the format: '+999999999'. Up to 12 digits allowed.")
    phone = models.CharField(validators=[phone_regex], max_length=15, blank=False,
                             unique=True)  # validators should be a list
    birthdate = models.CharField(max_length=100, blank=False)
    photo = models.ImageField(upload_to='prfile_picture', blank=True)
    bio = models.TextField(blank=True)
    labour_cost = models.IntegerField(blank=False)
    # for the history
    #updated_by = models.ForeignKey('auth.User', on_delete=models.SET_NULL, null=True)
    field_history = FieldHistoryTracker(['user'])

    def __str__(self):
        return self.user.username

    @property
    def _field_history_user(self):
        return self.users

    def get_absolute_url(self):
        return reverse("workerprofile:workerprofile", kwargs={"id": self.id})

# using signals
@receiver(post_save, sender=UserProfile.user)
def create_customer_profile(sender, instance, created, **kwargs):
    if created:
        UserProfile.objects.create(user=instance)


class CustomerProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    birthdate = models.CharField(max_length=100, blank=False)
    phone_regex = RegexValidator(regex=r'^\+?1?\d{6,12}$',
                                 message="Phone number must be entered in the format: '+999999999'. Up to 12 digits allowed.")
    phone = models.CharField(validators=[phone_regex], max_length=15, blank=False,
                             unique=True)  # validators should be a list
    photo = models.ImageField(upload_to='prfile_picture', blank=True)
    def __str__(self):
        return str(self.user)

    def get_absolute_url(self):
        return reverse("customerprofile:customerprofile", kwargs={"id": self.id})

    field_history = FieldHistoryTracker(['user'])

    @property
    def _field_history_user(self):
        return self.user


# using signals
@receiver(post_save, sender=CustomerProfile.user)
def create_customer_profile(sender, instance, created, **kwargs):
    if created:
        CustomerProfile.objects.create(user=instance)


