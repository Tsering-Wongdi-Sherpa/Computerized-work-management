mapboxgl.accessToken = 'pk.eyJ1IjoidHNlcmluZzEzIiwiYSI6ImNrbGh4bGo0ejAxbTkycXA4YTB6OGVmZ3gifQ.tHEM8iyRGEYSMi-35vDb8Q';
var map = new mapboxgl.Map({
    container: 'map',
    style: 'mapbox://styles/mapbox/streets-v11'
});
navigator.geolocation.getCurrentPosition(successLocation, errorLocation, {
    enableHighAccuracy: true
})

function successLocation(position) {
    setupMap([position.coords.longitude, position.coords.latitude])
    console.log(position.coords.latitude, position.coords.longitude)
    return position;
}

function errorLocation() {
    setupMap([27.731797333333333, 85.33393966666667])
}

function setupMap(center) {
    const map = new mapboxgl.Map({
        container: "map",
        style: "mapbox://styles/mapbox/streets-v11",
        center: center,
        zoom: 15,
    })

    const nav = new mapboxgl.NavigationControl()
    map.addControl(nav)

    var geocoder = new MapboxGeocoder({ // Initialize the geocoder
        accessToken: mapboxgl.accessToken, // Set the access token
        mapboxgl: mapboxgl, // Set the mapbox-gl instance
        marker: true, // Do not use the default marker style
    });

// Add the geocoder to the map
    map.addControl(geocoder, "top-left");

    map.on('click', function(e) {
        document.getElementById('info').innerHTML =
            // e.point is the x, y coordinates of the mousemove event relative
            // to the top-left corner of the map
            JSON.stringify(e.point) +
            '<br />' +
            // e.lngLat is the longitude, latitude geographical position of the event
            JSON.stringify(e.lngLat.wrap());
    });
    function getLocation(){
        document.getElementById('location').value = document.getElementById('info').value
    }

}