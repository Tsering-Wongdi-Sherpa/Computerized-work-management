from django.apps import AppConfig


class NotificationmanagementConfig(AppConfig):
    name = 'Notificationmanagement'
